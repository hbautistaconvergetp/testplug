"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'firstPlugDragonfly';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'first_plug_dragonfly';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnZmlyc3RQbHVnRHJhZ29uZmx5JztcbmV4cG9ydCBjb25zdCBQTFVHSU5fTkFNRSA9ICdmaXJzdF9wbHVnX2RyYWdvbmZseSc7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBRyxvQkFBbEI7O0FBQ0EsTUFBTUMsV0FBVyxHQUFHLHNCQUFwQiJ9