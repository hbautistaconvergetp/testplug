"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.

async function plugin(initializerContext) {
  const {
    FirstTestPluginPlugin
  } = await Promise.resolve().then(() => _interopRequireWildcard(require('./plugin')));
  return new FirstTestPluginPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJwbHVnaW4iLCJpbml0aWFsaXplckNvbnRleHQiLCJGaXJzdFRlc3RQbHVnaW5QbHVnaW4iLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsInJlcXVpcmUiXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQgfSBmcm9tICcuLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuXG4vLyAgVGhpcyBleHBvcnRzIHN0YXRpYyBjb2RlIGFuZCBUeXBlU2NyaXB0IHR5cGVzLFxuLy8gIGFzIHdlbGwgYXMsIEtpYmFuYSBQbGF0Zm9ybSBgcGx1Z2luKClgIGluaXRpYWxpemVyLlxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGx1Z2luKGluaXRpYWxpemVyQ29udGV4dDogUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0KSB7XG4gIGNvbnN0IHsgRmlyc3RUZXN0UGx1Z2luUGx1Z2luIH0gPSBhd2FpdCBpbXBvcnQoJy4vcGx1Z2luJyk7XG4gIHJldHVybiBuZXcgRmlyc3RUZXN0UGx1Z2luUGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XG59XG5cbmV4cG9ydCB0eXBlIHsgRmlyc3RUZXN0UGx1Z2luUGx1Z2luU2V0dXAsIEZpcnN0VGVzdFBsdWdpblBsdWdpblN0YXJ0IH0gZnJvbSAnLi90eXBlcyc7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBRUE7QUFDQTs7QUFFTyxlQUFlQSxNQUFNQSxDQUFDQyxrQkFBNEMsRUFBRTtFQUN6RSxNQUFNO0lBQUVDO0VBQXNCLENBQUMsR0FBRyxNQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FBQUMsSUFBQSxPQUFBQyx1QkFBQSxDQUFBQyxPQUFBLENBQWEsVUFBVSxHQUFDO0VBQzFELE9BQU8sSUFBSUwscUJBQXFCLENBQUNELGtCQUFrQixDQUFDO0FBQ3REIn0=