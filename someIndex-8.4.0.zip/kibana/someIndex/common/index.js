"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'someIndex';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'some_index';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnc29tZUluZGV4JztcbmV4cG9ydCBjb25zdCBQTFVHSU5fTkFNRSA9ICdzb21lX2luZGV4JztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQU8sTUFBTUEsU0FBUyxHQUFHLFdBQWxCOztBQUNBLE1BQU1DLFdBQVcsR0FBRyxZQUFwQiJ9